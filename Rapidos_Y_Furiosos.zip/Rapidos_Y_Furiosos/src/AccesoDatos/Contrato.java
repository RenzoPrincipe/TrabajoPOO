
package AccesoDatos;

import entidades.Auto;
import entidades.Conductor;
import entidades.Tarifa;
import java.time.LocalDateTime;

/**
 *
 * @author USUARIO
 */
public class Contrato {
     private Auto auto;
    private Tarifa tarifa;
    private Conductor conductor;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;
    private LocalDateTime fechaDevolucion;
    private String estado;

    public Contrato(Auto auto, Tarifa tarifa, Conductor conductor, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        this.auto = auto;
        this.tarifa = tarifa;
        this.conductor = conductor;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = "activo";
    }

    // Getters y Setters
    public Auto getAuto() { return auto; }
    public void setAuto(Auto auto) { this.auto = auto; }

    public Tarifa getTarifa() { return tarifa; }
    public void setTarifa(Tarifa tarifa) { this.tarifa = tarifa; }

    public Conductor getConductor() { return conductor; }
    public void setConductor(Conductor conductor) { this.conductor = conductor; }

    public LocalDateTime getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDateTime fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDateTime getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDateTime fechaFin) { this.fechaFin = fechaFin; }

    public LocalDateTime getFechaDevolucion() { return fechaDevolucion; }
    public void setFechaDevolucion(LocalDateTime fechaDevolucion) { this.fechaDevolucion = fechaDevolucion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public void registrarDevolucion(LocalDateTime fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
        this.estado = "finalizado";
        if (fechaDevolucion.isAfter(this.fechaFin)) {
            System.out.println("Entrega fuera de tiempo y se aplicará una Sancion...");
        }
    }
}
