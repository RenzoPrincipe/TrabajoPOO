
package entidades;

/**
 *
 * @author USUARIO
 */
public class Conductor {
     private String dni;
    private String nombres;
    private String nroLicencia;

    public Conductor(String dni, String nombres, String nroLicencia) {
        this.dni = dni;
        this.nombres = nombres;
        this.nroLicencia = nroLicencia;
    }

    // Getters y Setters
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }

    public String getNroLicencia() { return nroLicencia; }
    public void setNroLicencia(String nroLicencia) { this.nroLicencia = nroLicencia; }
}
