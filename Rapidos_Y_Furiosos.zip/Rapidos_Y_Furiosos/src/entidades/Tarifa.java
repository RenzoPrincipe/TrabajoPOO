
package entidades;

/**
 *
 * @author USUARIO
 */
public class Tarifa {
     private String codigo;
    private String turno;
    private int nroHoras;
    private double costoXHora;

    public Tarifa(String codigo, String turno, int nroHoras, double costoXHora) {
        this.codigo = codigo;
        this.turno = turno;
        this.nroHoras = nroHoras;
        this.costoXHora = costoXHora;
    }

    // Getters y Setters
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getTurno() { return turno; }
    public void setTurno(String turno) { this.turno = turno; }

    public int getNroHoras() { return nroHoras; }
    public void setNroHoras(int nroHoras) { this.nroHoras = nroHoras; }

    public double getCostoXHora() { return costoXHora; }
    public void setCostoXHora(double costoXHora) { this.costoXHora = costoXHora; }
}

